If you're using R2Api for this version (ShareSuite-R2.dll), please replace the 
MMHOOK_Assembly-CSharp.dll file in your R2Api folder with this dll!